player_manager.AddValidModel( "Metroid Prime - Varia Suit", "models/impulse/metroid/samus/samus_playermodel.mdl" )
player_manager.AddValidHands( "Metroid Prime - Varia Suit","models/impulse/metroid/c_arms/c_arms_variasuit.mdl",0,"0")

player_manager.AddValidModel( "Metroid Prime - Zero Suit", "models/impulse/metroid/samus/samus_zerosuit_playermodel.mdl" )
player_manager.AddValidHands( "Metroid Prime - Zero Suit","models/weapons/c_arms_chell.mdl",0,"0")

player_manager.AddValidModel( "Metroid Prime - Power Suit", "models/impulse/metroid/samus/samus_powersuit_playermodel.mdl" )
player_manager.AddValidHands( "Metroid Prime - Power Suit","models/impulse/metroid/c_arms/c_arms_powersuit.mdl",0,"0")

player_manager.AddValidModel( "Metroid Fusion - Fusion Suit", "models/impulse/metroid/samus/samus_fusion_playermodel.mdl" )
player_manager.AddValidHands( "Metroid Fusion - Fusion Suit","models/impulse/metroid/c_arms/c_arms_fusionsuit.mdl",0,"0")

player_manager.AddValidModel( "Metroid Prime 2 - Dark Suit", "models/impulse/metroid/samus/samus_darksuit_playermodel.mdl" )
player_manager.AddValidHands( "Metroid Prime 2 - Dark Suit","models/impulse/metroid/c_arms/c_arms_darksuit.mdl",0,"0")

player_manager.AddValidModel( "Metroid Prime 2 - Light Suit", "models/impulse/metroid/samus/samus_lightsuit_playermodel.mdl" )
player_manager.AddValidHands( "Metroid Prime 2 - Light Suit","models/impulse/metroid/c_arms/c_arms_lightsuit.mdl",0,"0")

player_manager.AddValidModel( "Metroid Prime 2 - Space Pirate", "models/impulse/metroid/pirate/spacepirate_mp2_playermodel.mdl" )
player_manager.AddValidHands( "Metroid Prime 2 - Space Pirate","models/impulse/metroid/c_arms/c_arms_prime2pirate.mdl",0,"0")

--player_manager.AddValidModel( "Metroid Prime 2 - Luminoth", "models/impulse/metroid/luminoth/luminoth.mdl" )

player_manager.AddValidModel( "Metroid Prime 2 - Dark Samus", "models/impulse/metroid/samus/darksamus_playermodel.mdl" )
player_manager.AddValidHands( "Metroid Prime 2 - Dark Samus","models/impulse/metroid/c_arms/c_arms_darksamus.mdl",0,"0")

player_manager.AddValidModel( "Metroid Prime 3 - PED Suit", "models/impulse/metroid/samus/samus_ped_playermodel.mdl" )
player_manager.AddValidHands( "Metroid Prime 3 - PED Suit","models/impulse/metroid/c_arms/c_arms_pedsuit.mdl",0,"00")

player_manager.AddValidModel( "Metroid Prime 3 - Dark Samus", "models/impulse/metroid/samus/darksamus_mp3_playermodel.mdl" )
player_manager.AddValidHands( "Metroid Prime 3 - Dark Samus","models/impulse/metroid/c_arms/c_arms_darksamus.mdl",0,"0")

player_manager.AddValidModel( "Metroid Prime 2 - Federation Trooper", "models/impulse/metroid/federation/federationtrooper_playermodel.mdl" )
player_manager.AddValidHands( "Metroid Prime 2 - Federation Trooper","models/impulse/metroid/c_arms/c_arms_gfm.mdl",0,"0")

player_manager.AddValidModel( "Metroid Prime 3 - Federation Soldier", "models/impulse/metroid/federation/federaton_soldier_playermodel.mdl" )
player_manager.AddValidHands( "Metroid Prime 3 - Federation Soldier","models/impulse/metroid/c_arms/c_arms_fed_soldier.mdl",0,"0")

player_manager.AddValidModel( "Metroid Prime 3 - Federation Crewmen Male", "models/impulse/metroid/federation/federaton_fleet_m.mdl" )

player_manager.AddValidModel( "Metroid Prime 3 - Federation Crewmen Female", "models/impulse/metroid/federation/federaton_fleet_f.mdl" )
player_manager.AddValidHands( "Metroid Prime 3 - Federation Crewmen Female","models/weapons/c_arms_chell.mdl",0,"0")